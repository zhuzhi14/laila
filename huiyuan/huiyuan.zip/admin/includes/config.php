<?php

include dirname(dirname(dirname(__FILE__))).'/data/config.php';


?>