##demo使用

任意PHP5 版本都可使用，直接拷贝到执行目录即可。
真实使用时请注意使用自己的BeeCloud App ID和App Secret。

微信内支付需要PHP-curl

