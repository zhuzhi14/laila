scp -P 12218 maila.tgz root@61.155.8.83:/opt/lampp/htdocs/ecnew

