tar cvfz maila.tgz js/user.js



