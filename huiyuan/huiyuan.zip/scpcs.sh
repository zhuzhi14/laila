scp -P 32222 maila.tgz root@58.221.92.138:/opt/lampp/htdocs/ecnew

