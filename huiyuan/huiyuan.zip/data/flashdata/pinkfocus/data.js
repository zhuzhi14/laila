imgUrl1="data/afficheimg/20150730nnuxaq.jpg";
imgtext1="";
imgLink1=escape("http://www.tongdui.cn/");
imgUrl2="data/afficheimg/20141022dacwiw.png";
imgtext2="";
imgLink2=escape("http://www.ecmoban.com/djd/");
imgUrl3="data/afficheimg/20141022nvtssl.png";
imgtext3="";
imgLink3=escape("http://www.ecmoban.com/weixin/ ");

var pics=imgUrl1+"|"+imgUrl2+"|"+imgUrl3;
var links=imgLink1+"|"+imgLink2+"|"+imgLink3;
var texts=imgtext1+"|"+imgtext2+"|"+imgtext3;