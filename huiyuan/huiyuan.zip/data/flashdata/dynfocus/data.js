imgUrl1="data/afficheimg/20150806xrplhi.jpg";
imgtext1="jpg";
imgLink1=escape("http://m.tongdui.cn/");
imgUrl2="data/afficheimg/20150805diowos.jpg";
imgtext2="maila";
imgLink2=escape("http://m.tongdui.cn/");
imgUrl3="data/afficheimg/20150805oveqth.jpg";
imgtext3="malacp";
imgLink3=escape("http://m.tongdui.cn");

var pics=imgUrl1+"|"+imgUrl2+"|"+imgUrl3;
var links=imgLink1+"|"+imgLink2+"|"+imgLink3;
var texts=imgtext1+"|"+imgtext2+"|"+imgtext3;